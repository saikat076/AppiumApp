package appiumproj;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class TestAppium {
	@Test
	public void openAmazonApp() throws InterruptedException, MalformedURLException {
		// Set DesiredCapabilities for the Android App
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("platformName", "Android");
		caps.setCapability("appium:platformVersion", "15"); // Adjust this to match your Android version
		caps.setCapability("appium:deviceName", "SaikatAndroid"); // Match this with your AVD or real device name
		caps.setCapability("appium:automationName", "UiAutomator2");
		caps.setCapability("appium:appPackage", "com.amazon.mShop.android.shopping");
		caps.setCapability("appium:appActivity", "com.amazon.mShop.home.HomeActivity");
		//caps.setCapability("noReset", true); // Optional: Avoid resetting app state

		AndroidDriver driver = null;


		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), caps);
		System.out.println("Amazon Shopping app launched successfully!");

		// Example: Locate an element using AppiumBy (replaces MobileElement)
//		WebElement searchBox = driver.findElement(AppiumBy.id("com.amazon.mShop.android.shopping:id/rs_search_src_text"));
//		searchBox.click();
//		searchBox.sendKeys("Laptops");

		Thread.sleep(10000);
		driver.quit();
		System.out.println("Driver session ended successfully.");
	}
}
